﻿
namespace LotteCinemaService.Model.Common.Raw
{
    public class ContractInfoRaw
    {
        public string AdvertiserID;
        public char UseYN;
        public string ContractID;
        public string ContractName;
        public string ContractDate;
        public string BeginDate;
        public string EndDate;
    }
}