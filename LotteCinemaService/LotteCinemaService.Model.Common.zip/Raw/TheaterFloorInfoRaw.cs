﻿
namespace LotteCinemaService.Model.Common.Raw
{
    public class TheaterFloorInfoRaw
    {
        public int Seq;
        public string Theater;
        public int FloorNo;
        public string ScreenCode;
        public string ScreenName;
        public char UseYN;
    }
}