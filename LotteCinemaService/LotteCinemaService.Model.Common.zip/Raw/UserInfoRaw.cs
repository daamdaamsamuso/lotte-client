﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LotteCinemaService.Model.Common.Raw
{
    public class UserInfoRaw
    {
        public string UserID;
        public int CinemaCode;
    }
}
