﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LotteCinemaService.Model.Common.Raw
{
    public class ISSpecialImageInfoRaw
    {
        public string Title;
        public string ISID;
        public string Theater;
        public string ItemID;
        public string BeginDate;
        public string EndDate;
    }
}
