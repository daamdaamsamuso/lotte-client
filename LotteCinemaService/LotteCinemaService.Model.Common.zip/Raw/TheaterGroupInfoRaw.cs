﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LotteCinemaService.Model.Common.Raw
{
    public class TheaterGroupInfoRaw : InfoRawBase
    {
        public string ID { get; set; }

        public string Name { get; set; }
    }
}
