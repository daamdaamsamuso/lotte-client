﻿
namespace LotteCinemaService.Model.Common
{
    public class DateTimeEx
    {
        public int Hour;
        public int Minute;
        public string Datetime;
    }
}