﻿
namespace LotteCinemaService.Model.Common
{
    public class MediaInfo : GroupInfo
    {
    }
}