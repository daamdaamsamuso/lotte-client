﻿using LotteCinemaService.Model.Enum;

namespace LotteCinemaService.Model.Common.Procedure
{
    public class DigitalSignSkinProcedure
    {
        public string SkinID;
        public string FileName;
        public string FileType;
        public ContentsType ContentsType;
    }
}