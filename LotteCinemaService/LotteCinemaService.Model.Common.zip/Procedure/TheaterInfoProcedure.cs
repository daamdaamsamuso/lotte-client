﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LotteCinemaService.Model.Common.Procedure
{
   public class TheaterInfoProcedure
    {
       public string TheaterName;
       public string TheaterCode;
    }
}
