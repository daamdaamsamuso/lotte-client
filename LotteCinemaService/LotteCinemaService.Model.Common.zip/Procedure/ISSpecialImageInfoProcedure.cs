﻿using LotteCinemaService.Model.Enum;

namespace LotteCinemaService.Model.Common.Procedure
{
    public class ISSpecialImageInfoProcedure
    {
        public string ISID;
        public string BeginDate;
        public string EndDate;
        public int ContentsID;
        public string FileName;
        public string FileType;
        public ContentsType ContentsType;
    }
}