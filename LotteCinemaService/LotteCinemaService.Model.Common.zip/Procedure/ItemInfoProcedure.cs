﻿using LotteCinemaService.Model.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LotteCinemaService.Model.Common.Procedure
{
   public class ItemInfoProcedure
    {
        public string ItemName;
        public ItemID ItemCode;
    }
}
