﻿using LotteCinemaService.Model.Common.Raw;

namespace LotteCinemaService.Model.Common.Procedure
{
    public class ContractInfoProcedure : ContractInfoRaw
    {
        public string AdvertiserName;
    }
}