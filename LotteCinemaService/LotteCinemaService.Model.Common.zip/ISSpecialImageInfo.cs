﻿using System.Collections.Generic;

namespace LotteCinemaService.Model.Common
{
    public class ISSpecialImageInfo
    {
        public string ISID;
        public string BeginDate;
        public string EndDate;
        public List<ContentsInfo> ContentsList;
    }
}