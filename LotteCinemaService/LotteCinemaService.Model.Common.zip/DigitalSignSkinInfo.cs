﻿using LotteCinemaService.Model.Enum;

namespace LotteCinemaService.Model.Common
{
    public class DigitalSignSkinInfo
    {
        public string SkinID;
        public string FileName;
        public ContentsType ContentsType;
        public string FtpFilePath;
        public string LocalFilePath;
    }
}